const fs = require('fs');
const path = require('path');
const { createGzip } = require('zlib');
const { promisify } = require('util');
const pipeline = promisify(require('stream').pipeline);

// Simple ZIP file creator (no external dependencies)
class SimpleZip {
  constructor() {
    this.files = [];
    this.offset = 0;
  }

  addFile(name, data) {
    const uncompressedSize = data.length;
    const compressedData = data; // Store uncompressed for simplicity
    const crc = this.crc32(data);
    
    this.files.push({
      name,
      data: compressedData,
      crc,
      uncompressedSize,
      compressedSize: compressedData.length,
      offset: this.offset
    });
    
    this.offset += 30 + name.length + compressedData.length;
  }

  crc32(buf) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
      }
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  generate() {
    const localHeaders = [];
    const centralHeaders = [];
    let offset = 0;

    for (const file of this.files) {
      // Local file header
      const localHeader = Buffer.alloc(30 + file.name.length);
      localHeader.writeUInt32LE(0x04034b50, 0); // Signature
      localHeader.writeUInt16LE(20, 4); // Version needed
      localHeader.writeUInt16LE(0, 6); // Flags
      localHeader.writeUInt16LE(0, 8); // Compression (none)
      localHeader.writeUInt16LE(0, 10); // Mod time
      localHeader.writeUInt16LE(0, 12); // Mod date
      localHeader.writeUInt32LE(file.crc, 14); // CRC-32
      localHeader.writeUInt32LE(file.compressedSize, 18); // Compressed size
      localHeader.writeUInt32LE(file.uncompressedSize, 22); // Uncompressed size
      localHeader.writeUInt16LE(file.name.length, 26); // Filename length
      localHeader.writeUInt16LE(0, 28); // Extra field length
      localHeader.write(file.name, 30); // Filename
      
      localHeaders.push(Buffer.concat([localHeader, file.data]));
      
      // Central directory header
      const centralHeader = Buffer.alloc(46 + file.name.length);
      centralHeader.writeUInt32LE(0x02014b50, 0); // Signature
      centralHeader.writeUInt16LE(20, 4); // Version made by
      centralHeader.writeUInt16LE(20, 6); // Version needed
      centralHeader.writeUInt16LE(0, 8); // Flags
      centralHeader.writeUInt16LE(0, 10); // Compression
      centralHeader.writeUInt16LE(0, 12); // Mod time
      centralHeader.writeUInt16LE(0, 14); // Mod date
      centralHeader.writeUInt32LE(file.crc, 16); // CRC-32
      centralHeader.writeUInt32LE(file.compressedSize, 20); // Compressed size
      centralHeader.writeUInt32LE(file.uncompressedSize, 24); // Uncompressed size
      centralHeader.writeUInt16LE(file.name.length, 28); // Filename length
      centralHeader.writeUInt16LE(0, 30); // Extra field length
      centralHeader.writeUInt16LE(0, 32); // File comment length
      centralHeader.writeUInt16LE(0, 34); // Disk number start
      centralHeader.writeUInt16LE(0, 36); // Internal file attributes
      centralHeader.writeUInt32LE(0, 38); // External file attributes
      centralHeader.writeUInt32LE(file.offset, 42); // Relative offset
      centralHeader.write(file.name, 46); // Filename
      
      centralHeaders.push(centralHeader);
      offset += localHeader.length + file.data.length;
    }

    const centralDirOffset = offset;
    const centralDirBuffer = Buffer.concat(centralHeaders);
    const centralDirSize = centralDirBuffer.length;

    // End of central directory
    const endRecord = Buffer.alloc(22);
    endRecord.writeUInt32LE(0x06054b50, 0); // Signature
    endRecord.writeUInt16LE(0, 4); // Disk number
    endRecord.writeUInt16LE(0, 6); // Disk with central dir
    endRecord.writeUInt16LE(this.files.length, 8); // Entries on this disk
    endRecord.writeUInt16LE(this.files.length, 10); // Total entries
    endRecord.writeUInt32LE(centralDirSize, 12); // Central dir size
    endRecord.writeUInt32LE(centralDirOffset, 16); // Central dir offset
    endRecord.writeUInt16LE(0, 20); // Comment length

    return Buffer.concat([...localHeaders, centralDirBuffer, endRecord]);
  }
}

// Walk directory recursively
function walkDir(dir, baseDir = dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  for (const file of list) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      if (file === 'node_modules' || file === '.git' || file === 'dist' || file === '.env.local') {
        continue;
      }
      results = results.concat(walkDir(filePath, baseDir));
    } else {
      const relativePath = path.relative(baseDir, filePath);
      // Skip .env files
      if (relativePath.startsWith('.env') || relativePath.endsWith('.zip')) {
        continue;
      }
      results.push({ path: relativePath, fullPath: filePath });
    }
  }
  
  return results;
}

async function main() {
  const zip = new SimpleZip();
  const files = walkDir('/project');
  
  console.log(`Adding ${files.length} files to zip...`);
  
  for (const file of files) {
    try {
      const data = fs.readFileSync(file.fullPath);
      zip.addFile(file.path, data);
      console.log(`  Added: ${file.path}`);
    } catch (err) {
      console.error(`  Error reading ${file.path}: ${err.message}`);
    }
  }
  
  const zipBuffer = zip.generate();
  fs.writeFileSync('/project/.freebuff-data-transfer.zip', zipBuffer);
  console.log(`\nCreated .freebuff-data-transfer.zip (${zipBuffer.length} bytes)`);
}

main().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
